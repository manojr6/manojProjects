package tdAssessment;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;





public class amazonApp extends amazonPageObjects {


	WebDriver driver;

	@BeforeTest
	public  void beforeTest() throws IOException  {

		//System.setProperty("webdriver.http.factory", "jdk-http-client");
		FileInputStream stream= new FileInputStream("config.properties");
		Properties properties= new  Properties();
		properties.load(stream);
		String browser=properties.getProperty("browser");
		String driverLocation=properties.getProperty("DriverLocation");


		if(browser.equalsIgnoreCase("Chrome")) 
		{
			System.setProperty("webdriver.chrome.driver",driverLocation);
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			String url=properties.getProperty("url");
			driver.get(url);

		}

	}

	@Test
	public  void Test() 
	{

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		PageFactory.initElements(driver, amazonPageObjects.class);

		amazonImplementation amazonImplementation = new amazonImplementation();
		amazonImplementation.setText(searchBox, "fossil");

		amazonImplementation.click(searchButton);
		String currentTab=amazonImplementation.getSingleWindow(driver);

		amazonImplementation.click(Item);

		Set<String> allTabs=amazonImplementation.getMultipleWindows(driver);
		for (String newTab : allTabs) {
			if (newTab!=currentTab) {
				driver.switchTo().window(newTab);
			}
		}

		amazonImplementation.click(addButton);
		String cartCount=amazonImplementation.getText(cartCountButton);
		Assert.assertEquals(cartCount, "1");
		System.out.println("item added successfully");

		amazonImplementation.click(gotoCartButton);
		amazonImplementation.click(deleteButton);

		String cartCount1=amazonImplementation.getText(cartCountButton);

		Assert.assertEquals(cartCount1, "0");
		System.out.println("item removed successfully");


	}

	@AfterTest
	public  void afterTest() {
		driver.quit();
	}
}




